import java.util.Scanner;

public class Question01 {

	public static void main(String[] args) {
		
		String yeartype="2008 novel";
		boolean buldum = false;
		int select = 0, i = 0, get=0, j=0, returnn=0;
		String books[] = { "The Outsider, Stephen King, Novel", "Improbable, Adam Fawer, Novel",
				"Doctor Sleep, Stephen King, Novel", "Java, Walter Savitch, Technical", "Relativity, Albert Einstein, Scientific", "The Evolution of Physics, Albert Einstein, Scientific",
				"The Success Principles, Jack Canfield, Self-help", "Hack Your Habits, Joanna Jast, Selfhelp",
				"Unlimited Memory, Kevin Horsley, Self-help", "First 100 Words, Roger Priddy, Children" };
		int years[] = { 2018, 2006, 2013, 2014, 1916, 1938, 1997, 2016, 2016, 2011 };
		int counts[] = { 10, 13, 5, 28, 4, 3, 2, 4, 1, 2 };
		Scanner rosa = new Scanner(System.in);
		
		System.out.println("Welcome to The Library");
		
		while(select != 7){
			System.out.println("1 View All \r\n2 View Available \r\n3 View Authors \r\n4 View By Year and Type \r\n5 Get \r\n6 Return \r\n7 Exit \r\nOperation:");
			select= rosa.nextInt();
			String temp = rosa.nextLine();
			if(select==7){
				System.out.println("Good bye.");
				System.exit(0);
			}
			
			if(select == 1){
				for(i=0; i<books.length;i++ ){
					System.out.print((i+1) + "-" +books[i].substring(0, books[i].indexOf(",")));
					System.out.println(" ("+years[i]+")");
				}
			}
			
			if(select == 2){
				for(i=0; i<books.length;i++ ){
					if(counts[i]>0){
					System.out.print((i+1) + "-" +books[i].substring(0, books[i].indexOf(",")));
					System.out.print(" ("+years[i]+")");
					System.out.println(" - " +counts[i] +" available.");}
			}
		}
			
			if(select == 3){
				int r=0;
				for(i=0; i<books.length; i++){	
						String aut =books[i].substring((books[i].indexOf(",")+2),books[i].lastIndexOf(","));
					{	
						boolean exists = false;
						for(j=0; j<i;j++){
							String aut2= books[j].substring((books[j].indexOf(",")+2),books[j].lastIndexOf(","));
							if(aut.equals(aut2))
								exists = true;
						}
						
						if(!(exists)){
							System.out.println(aut);
						}	
					}}
				}
			
			if(select == 4){
				
				System.out.println("Enter publication year and book type: ");
						yeartype = rosa.nextLine();
						String year = yeartype.substring(0, yeartype.indexOf(" "));
						int year1 = Integer.parseInt(year);
						String type = yeartype.substring(yeartype.indexOf(" ")+1);
				
				for(i=0; i<books.length; i++){
					if(year1==years[i] && type.equalsIgnoreCase(books[i].substring(books[i].lastIndexOf(",")+2))){
						buldum = true;
							System.out.print(i+1 + "-" +books[i].substring(0, books[i].indexOf(",")) +"-" +books[i].substring(books[i].lastIndexOf(",")+2));
							System.out.print(" ("+years[i]+")");	
							System.out.println("");
					}
				}
					if(!buldum)
					System.out.println("No "+type +" books found which was published in "+year1+".");
			}
			
	
			if(select == 5){
				for(i=0; i<books.length;i++ ){
				if(counts[i]>0){
				System.out.print((i+1) + "-" +books[i].substring(0, books[i].indexOf(",")));
				System.out.println(" ("+years[i]+")");}
			}
				System.out.print("Please select a book to get: ");
				get = rosa.nextInt();
				if(get>10){
					System.out.println("Wrong book no!");
				}
				else{
					if(counts[get-1]<1)
						System.out.println("No books available.");
					else{
						System.out.print("You have got " +books[get-1].substring(0, books[get-1].indexOf(",")) +"-");
						System.out.println(books[get-1].substring((books[get-1].indexOf(",")+2),books[get-1].lastIndexOf(",")) +"  (" +books[get-1].substring(books[get-1].lastIndexOf(",")+2) +").");
						System.out.println("Publication year: " +years[get-1]);
						counts[get-1]--;
						}
			}
		}
			
			if(select == 6){
				
				for(i=0; i<books.length;i++ ){
					if(counts[i]>0){
					System.out.print((i+1) + "-" +books[i].substring(0, books[i].indexOf(",")));
					System.out.println(" ("+years[i]+")");}
				}
				System.out.print("Please select a book to return: ");
				returnn =rosa.nextInt();
				if(returnn>10)
					System.out.println("Wrong book no!");
				else{
				System.out.print("You have returned "+books[returnn-1].substring(0, books[returnn-1].indexOf(",")) +"-");
				System.out.println(books[returnn-1].substring((books[returnn-1].indexOf(",")+2),books[returnn-1].lastIndexOf(",")) +" ("+years[returnn-1] +"). Thank you for choosing our library." );
				counts[returnn-1]++;	
				}
				
			}
			if(select >7 || select<1){
				System.out.println("Invalid input. Please try again.");
			}
			

			
			
			
			
			
			
			
	System.out.println("");		
}
		}}