
public class Question1 {

	public static void main(String[] args) {
		double result;
		
		result = (Math.pow(1,2)+Math.pow(2,2)+Math.pow(3,2)+Math.pow(4,2)+Math.pow(5,2));		
		System.out.println("sum(1^2+2^2+3^2+...+5^2) = " + result);

		result = (Math.pow((-1),2)+Math.pow((-2),2)+Math.pow((-3),2)+Math.pow((-4),2)+Math.pow((-5),2));
		System.out.println("sum((-1)^2+(-2)^2+(-3)^2+...+(-5)^2) = " + result);
		
//
	}

}
