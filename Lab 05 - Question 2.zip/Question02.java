import java.util.Scanner;

public class Question02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner passanger = new Scanner(System.in);
		int sayı;
		
		System.out.println("Please enter a number between 120 and 209: ");
		sayı = passanger.nextInt();
		if (sayı >119 && sayı <210){
		
		int yuzler = ( sayı / 100) ;
		int yuz = ( sayı % 100);
		int onlar = ( yuz / 10 );
		int on = ( yuz % 10 );
		int birler = ( on / 1);
		int bir = ( on % 1 );
		String first="", second="", thirth ="";
		switch (yuzler)
		{ 
		case 1:
			first = " One Hundred ";
			break;
		case 2:
			first = " Two Hundred ";
			break;
		
		}
		switch (onlar)
		{case 0:
			second = "";
			break;
		case 2:
			second = "Twenty";
			break;
		case 3:
			second = "Thirty";
			break;
		case 4:
			second = "Forty";
			break;
		case 5:
			second = "Fifty";
			break;
		case 6:
			second = "Sixty";
			break;
		case 7:
			second = "Seventy";
			break;
		case 8:
			second = "Eighty";
			break;
		case 9:
			second = "Ninety";
			break;
		}
		switch (birler)
		{case 0:
			thirth ="";
			break;
		case 1:
			thirth ="one";
			break;
		case 2:
			thirth ="two";
			break;
		case 3:
			thirth ="three";
			break;
		case 4:
			thirth ="four";
			break;
		case 5:
			thirth ="five";
			break;
		case 6:
			thirth ="six";
			break;
		case 7:
			thirth ="seven";
			break;
		case 8:
			thirth ="eight";
			break;
		case 9:
			thirth ="nine";
			break;
		
		
		}
	System.out.print("You have entered: " +first +second+thirth);
		}else{
	System.out.print("Wrong number! It is out of the range.");
		}
		
				
	}

}