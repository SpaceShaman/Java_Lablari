import java.util.Scanner;

public class Lab04Q3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner imagine = new Scanner(System.in);
		int quiz, mid, fnal;
		double avarage;
		String grade;
		
		System.out.print("Enter Quiz: ");
		quiz = imagine.nextInt();
		System.out.print("Enter Mid-term: ");
		mid = imagine.nextInt();
		System.out.print("Enter Final: ");
		fnal = imagine.nextInt();
		
		avarage = (quiz + mid + fnal) / 3.0;
		if (avarage>=90){
			grade = "AA";
			System.out.print("Letter grade is " +grade +".");
		}
		else if (avarage>=70 && avarage<90){
			grade = "BB";
			System.out.print("Letter grade is " +grade +".");
		}
		else if (avarage>=50 && avarage<70){
			grade = "CC";
			System.out.print("Letter grade is " +grade +".");
		}
		else if (avarage<50){
			grade = "F";
		System.out.print("Letter grade is " +grade +".");
}
		
		
		
	}

}
