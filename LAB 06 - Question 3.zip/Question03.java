import java.util.Scanner;

public class Question03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner walk = new Scanner(System.in);
		String id;
		int score = 0,wight_total=0, weight = 0, total =0;
		int i = 0;
		System.out.print("Enter the student's id: ");
		id = walk.next();
		if (Character.isAlphabetic(id.charAt(i)) || id.length() == 9)
			System.out.println("Enter the scores: ");
		while (score != -1 || weight != -1) {
			score = walk.nextInt();
			if (score == -1) {
				System.out.println("Invalid input");
				return;
			}else{
				if(score>100 || score<0){
					System.out.println("Invalid input");
					return;
				}
			}// score kontol
			weight = walk.nextInt();
			if (weight == -1) {
				System.out.println("Invalid input");
				return;
			}else{
				if(weight>100 || weight<0){
					System.out.println("Invalid input");
					return;
				}
				else{
					wight_total+=weight;
				}
			}// we kontol
			 total += (weight*score);
		}

	}

}
