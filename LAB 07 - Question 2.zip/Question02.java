import java.util.Locale;
import java.util.Scanner;

public class Question02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner cage = new Scanner(System.in);
		cage.useLocale(Locale.US); // use decimal points

		int count=0;
		double score=0.0, sum =0.0, max=0.0, min=100.0, avarage=0.0;
		System.out.print("Enter the count of scores: ");
		count= cage.nextInt();
		if (count <0 || count >30)
		{
			System.out.println("Invalid Input");
		}else{
		
		for(int i= 1; i<=count; i++){
			System.out.println(":");
			score = cage.nextDouble();
			if (score<0.0 || score >100.0){
				System.out.println("Invalid Input");
				System.exit(0);
			}
			sum += score;
			if(score>max){
				max=score;
			}
			if(score<min){
				min=score;
			}
		}
		avarage= sum/count;
		System.out.println("\n" + "Average: " +(Math.round(avarage*100.0)/100.0));
		System.out.println("Minimum: " +min);
		System.out.println("Maximum: " +max);
		}
		
	}
	
}



	


	
