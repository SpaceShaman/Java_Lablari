	import java.util.Scanner;
	
	public class Question03 {
	
	public static void main(String[] args) {

	
		
		
		Scanner coin = new Scanner(System.in);
		String line = "";
		int n= 1;
		System.out.println("Enter an input string: ");
			line = coin.nextLine();
		while(!(line.equalsIgnoreCase("QUIT"))) 
			{
			n = line.length();	
				
				{if(n<=1)
				{System.out.println("The input is in order");}
				else {{
					int i = -1;
					while (i<line.length()-3)
					{   i++;
					int test =line.substring(i,i+1).compareTo(line.substring(i+1,i+2));
						
						if(test>0)
							break;
						if (test<=0)
							continue;
					}
					if (line.substring(i,i+1).compareTo(line.substring(i+1,i+2))<0) {
						System.out.print("The input is in order");
					}
					else {
					System.out.println("The input is out of order");
					}
					}}
				System.out.println("\n" +"\n" + "Enter an input string: ");
				String line2 = coin.nextLine();
				line =line2;
			if (!(line.equalsIgnoreCase("QUIT")))
			continue;
			if (line.equalsIgnoreCase("QUIT")) 
			{
				System.out.println("Goodbye");
				}
			break;
			
			}
	
	
		}

	}

		
		
	}


