import java.util.Scanner;

public class Question01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tom = new Scanner(System.in);
		int number=0;
		System.out.println("Enter a number from 1 to 15: ");
		number= tom.nextInt();
		if (number <0 || number >15)
		{
			System.out.println("Invalid Input");
		}
		System.out.println("");
		for(int i= 1; i<=number; i++){
		for ( int k=1; k <=(number-i); k++)
			System.out.print(" ");
		
		for(int j=1; j<=i; j++){
			if (i%2==0)
			System.out.print(":");	
			if (i%2==1)
			System.out.print(".");	
		}
		System.out.println("");
			
		}
			
		}
}
		
	


