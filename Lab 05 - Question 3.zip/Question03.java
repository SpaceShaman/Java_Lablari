import java.util.Scanner;

import javax.swing.plaf.synth.SynthSeparatorUI;

public class Question03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner beegees = new Scanner(System.in);
		String date, day, month, week="", ay="";
		int  slash,day1,month1,week1;
		System.out.println("Enter day and month:");
		date = beegees.next();
		slash = date.indexOf("/");
		day = date.substring(0, slash);
		month = date.substring(slash+1);
		day1 = Integer.parseInt(day);
		month1 = Integer.parseInt(month);
		week1 =day1 % 7;
		switch (week1){
		case 0:
			week = "Sunday";
		break;
		case 1:
			week = "Monday";
		break;
		case 2:
			week = "Tuesday";
		break;
		case 3:
			week = "Wednesday";
		break;
		case 4:
			week = "Thursday";
		break;
		case 5:
			week = "Friday";
		break;
		case 6:
			week = "Saturday";
		break;
		}
		switch (month1){
		case 1:
			ay = "January";
		break;
		case 2:
			ay = "February";
		break;
		case 3:
			ay = "March";
		break;
		case 4:
			ay = "April";
		break;
		case 5:
			ay = "May";
		break;
		case 6:
			ay = "June";
		break;
		case 7:
			ay = "July";
		break;
		case 8:
			ay = "August";
		break;
		case 9:
			ay = "September";
		break;
		case 10:
			ay = "October";
		break;
		case 11:
			ay = "November";
		break;
		case 12:
			ay = "December";
		break;
		}
		
		System.out.println(day +" " +ay + " is " +week);
	}

}
