import java.util.Scanner;

public class Question02 {

	public static void main(String[] args) {

		Scanner queen = new Scanner(System.in);
		int number = 1000000, number1 = 1000004;
		
		System.out.print("Enter a number from 2 to 1000000: ");
		number = queen.nextInt();
		do {if (number<=1000000 && number>=2)
				break;
				System.out.print("Incorrect input\r\n" + "Enter a number from 2 to 1000000:");
				number1 = queen.nextInt();
				number = number1;
			if (!(number<=1000000 && number>=2))
				continue;
		} while(!(number<=1000000 && number>1));
		
		
		//prime test
		int i = 2;
		if (number == 2) {System.out.println( +number + " is Prime");}
		else {
	    while (i<(Math.sqrt(number))) {
	        i++;
	       int prime = number % i ;	
	      
	       if (number % i == 0)
	    	   break;
	       if (prime !=0)
	    	   continue;
		   }
	    
	    if (number % i != 0) {
           System.out.println( +number + " is Prime"); 
            
        
        } else {
            System.out.println(+number +" is Not Prime");
           
       
        

	}
}}
}



