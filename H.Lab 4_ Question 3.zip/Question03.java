
import java.util.Scanner;

public class Question03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		
		Scanner light = new Scanner(System.in); 
		
		int a,e = 0;
		double max= 0.0;
		
		System.out.print("Please enter the capacity of the array: ");
		a = light.nextInt();
		double sayi[] = new double[a+1];
		int i=0;
		for (i = 1; i <= a; i++) 
		{ 
		System.out.print("Please enter the element "+i+": ");
		sayi[i] = light.nextDouble();  
		} 
		for(i = 1; i <= a; i++) {
			if(sayi[i]>max){
				max=sayi[i];
				 e=i;
		}
			
			}
			System.out.println("The maximum value of the array is: " +max); 
			System.out.println("It is the element " +e +".");
}
}