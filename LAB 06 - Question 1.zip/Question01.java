import java.util.Scanner;

public class Question01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner moon = new Scanner(System.in);
		String text;

		System.out.println("Enter sentences: ");
		text = moon.nextLine();
		int kelime = 0, cumle1 = 0, i = 0, l = 0, sayý=0;
		
		while (i <= text.length() - 1) {
			// 123 *** Character.isAlp..()
			if (Character.isAlphabetic(text.charAt(i))) {
				sayý++;
				if (text.charAt(i + 1) == ' ' || text.charAt(i + 1) == '.' || text.charAt(i + 1) == '?'
						|| text.charAt(i + 1) == '!') {
					kelime++;

				}
			}
			if (text.charAt(i) == '.' || text.charAt(i) == '?' || text.charAt(i) == '!') {
				cumle1++;
			}
			i++;

		}
		if (cumle1 == 0 || sayý<2) {// || (!(Character.isAlphabetic(text.charAt(i))))
			System.out.println("\n" + "Error: not a valid input.");
		} else {
			if (cumle1 == 1) {
				System.out.println("There are " + (kelime) + "  words in " + (cumle1 ) + " sentence.");
			} else {
				System.out.println("There are " + (kelime) + "  words in " + (cumle1 ) + " sentences.");
			}
		}

	}

}
