import java.util.Scanner;

public class Questin01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner footlose = new Scanner(System.in);
		String letter;
		System.out.println("Enter a letter:");
		letter = footlose.next();
		int i;
		i= letter.length();
		switch (i)
		{
		case 1:
			switch(letter)
			{case "a":
			case "e":
			case "ý":
			case "i":
			case "o":
			case "ö":
			case "ü":	
			case "u":
				System.out.println("This letter is vowel.");
			break;
			default:
				System.out.println("This letter is consonant.");
				break;
			}
			break;
		default:
			System.out.println("This is not a letter!");
			break;
			
		}
		
		
		
		
		
	}

}
