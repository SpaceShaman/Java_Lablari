import java.util.Scanner;

public class Question_1 {

	public static void main(String[] args) {
		
		Scanner rule = new Scanner(System.in);
		String select_="";
		String search =null;
		int select = 0;
		int row =4, seat =5;
		int i=0, j=0;
		int r=0, s=0;
		String[][] name= new String [row] [seat];
		int [] [] ticket = new int [row] [seat];
		System.out.println("Welcome!!! Please select");
		while (select != 4) {
			System.out.println("1 View SeatPlan\r\n" + "2 Make Reservation\r\n" + "3 View Reservation\r\n" + 
					"4 Exit\r\n" + "Operation: ");
			select = rule.nextInt();
			select_= Integer.toString(select);
			select = Integer.parseInt(select_);
			
			if(select == 4) {
						System.out.println("Exit...");
						System.exit(0);
					}
			
			if (select == 1) {
					for ( i=1;i<row;i++) {
						System.out.print("Row"+i);
						System.out.print("  ");
						for ( j=1;j<seat;j++) {
							System.out.print(j+"-");
							if(ticket[i][j]==0)
						System.out.print("-");	
							else
								System.out.print("X");
								System.out.print(" ");		
						}
						System.out.println("");
				}	
			}
			if (select == 2) {
						System.out.println("1st Row (Price 100 TL)\r\n" + 
								"2nd Row (Price 50 TL)\r\n" + "3nd Row (Price 25 TL)");
						System.out.print("Select Row & Seat:");
						r = rule.nextInt();s = rule.nextInt();
						System.out.print("Name: ");
						name[r][s] = rule.next();
						if (ticket[r][s]==2) {
							System.out.println("Row"+r+"/Seat"+s+" is full.\r\n" + 
									"Please select another seat...");
						}else {
						
						System.out.println("Row"+r+"/Seat"+s+" is reserved.");
					}}
					name[r][s] = name[r][s];
					if(name[r][s] == name[r][s]){
					i=r;j=s;
					if (i==r && j== s)
						ticket[i][j]=2;}
					
					
					
					if(select == 3) {
						boolean seat_ = false;
						System.out.println("Enter Name:");
						search = rule.next();
						System.out.println("Reservation Details:");
						for ( i=1;i<row;i++) {
							for ( j=1;j<seat;j++) {
								if(search != null && search.equalsIgnoreCase(name[i][j])) {
									seat_= true;
									r=i;
									s=j;
								}	
							}
					}if(seat_) {
						System.out.println("Name: "+search.toUpperCase());
						System.out.println("Row"+r+"/Seat"+s);
					}
					else {
						System.out.println("No reservation for your name.");
					}
					}

			
			
			
			
			
			
			
			
			
			
			
		}
		
		
		
		
	}

}
