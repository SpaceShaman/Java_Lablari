import java.util.Scanner;

public class Question01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner ready = new Scanner(System.in);
		
		int a=3;
		
		String name[] = new String[a+1];
		String location[]= new String[a+1];
		int price[] = new int[a+1];
		int i=0;
		for (i = 1; i<=a; i++) 
		{System.out.println("Please enter the hotel's name: ");
		name[i]= ready.next();
		
		System.out.println("Please enter the hotel's price: ");
		price[i]= ready.nextInt();
		
		System.out.println("Please enter the hotel's location: ");
		location[i]= ready.next();
		}
		System.out.println("Hotels cheaper than $60 and located in Europa:");
		for(i = 1; i <= a; i++) {
			if(location[i].equals("Europa") && price[i]<60){
				System.out.println(name[i]+"   $"+price[i]);
			}
			
	}
	}
}