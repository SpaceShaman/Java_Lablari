import java.util.Scanner;

public class StockItemTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner(System.in);
		
		StockItem item1 = new StockItem();
		System.out.println("Please enter stock no and name of stock item 1: ");
		item1.stockNo = scan.next();
		item1.name = scan.next();
		System.out.println("Please enter stock amount and price of stock item 1: ");
		item1.totalStock = scan.nextInt();
		item1.price = scan.nextDouble();
		item1.price = (Math.round(item1.price*10.0)/10.0);
		if (item1.totalStock<=0){
			System.out.println("Stock amount and price must be grater than 0!");
			System.exit(0);
		}
		
		
		StockItem item2 = new StockItem();
		System.out.println("Please enter stock no and name of stock item 2: ");
		item2.stockNo = scan.next();
		item2.name = scan.next();
		System.out.println("Please enter stock amount and price of stock item 2: ");
		item2.totalStock = scan.nextInt();
		item2.price = scan.nextDouble();
		item2.price = (Math.round(item2.price*10.0)/10.0);
		if (item2.totalStock<=0){
			System.out.println("Stock amount and price must be grater than 0!");
			System.exit(0);
		}
		
		StockItem item3 = new StockItem();
		System.out.println("Please enter stock no and name of stock item 3: ");
		item3.stockNo = scan.next();
		item3.name = scan.next();
		System.out.println("Please enter stock amount and price of stock item 3: ");
		item3.totalStock = scan.nextInt();
		item3.price = scan.nextDouble();
		item3.price = (Math.round(item3.price*10.0)/10.0);
		if (item3.totalStock<=0){
			System.out.println("Stock amount and price must be grater than 0!");
			System.exit(0);}
			

		System.out.println("Please enter extra stock amount for "+item1.getName() +": ");
		
		int extra= scan.nextInt();
		item1.increaseTotalStock(extra);
		
		System.out.println("Please enter extra stock amount for "+item2.getName() +": ");
		extra= scan.nextInt();		
		item2.increaseTotalStock(extra);
		
		System.out.println("Please enter extra stock amount for "+item3.getName() +": ");
		extra= scan.nextInt();
		item3.increaseTotalStock(extra);
		
		System.out.println("Please enter the raise percentage for all stock items: ");
		int percen = scan.nextInt();
		if (percen<0 || percen> 100){
			System.out.println("Percentage must be between 0 and 100!");
			System.exit(0);
		}
		
		double tempprice1=0;
		tempprice1 = item1.getPrice()*((100+percen)/100.0);
		item1.setPrice(tempprice1);
		
		double tempprice2=0;
		tempprice2 = item2.getPrice()*((100+percen)/100.0);
		item2.setPrice(tempprice2);
		
		double tempprice3=0;
		tempprice3 = item3.getPrice()*((100+percen)/100.0);
		item3.setPrice(tempprice3);
		
		System.out.println("Information about stock item 1:" );
		System.out.println("Stock No : " +item1.getStockNo());
		System.out.println("Name : " +item1.getName());
		System.out.println("Total Stock : " + item1.getTotalStock());
		System.out.println("Price : " +	(Math.round(item1.getPrice()*100.0)/100.0));
		System.out.println("Total Price : " +(Math.round(item1.calculateTotalPrice()*10.0)/10.0));
		System.out.println("");
		
		System.out.println("Information about stock item 2:" );
		System.out.println("Stock No : " +item2.getStockNo());
		System.out.println("Name : " +item2.getName());
		System.out.println("Total Stock : " + item2.getTotalStock());
		System.out.println("Price : " +	(Math.round(item2.getPrice()*100.0)/100.0));
		System.out.println("Total Price : " +(Math.round(item2.calculateTotalPrice()*10.0)/10.0));
		System.out.println("");
		
		System.out.println("Information about stock item 3:" );
		System.out.println("Stock No : " +item3.getStockNo());
		System.out.println("Name : " +item3.getName());
		System.out.println("Total Stock : " + item3.getTotalStock());
		System.out.println("Price : " +	(Math.round(item3.getPrice()*100.0)/100.0));
		System.out.println("Total Price : " +(Math.round(item3.calculateTotalPrice()*10.0)/10.0));
		System.out.println("");

		
	
		
			
	}
    			
}
