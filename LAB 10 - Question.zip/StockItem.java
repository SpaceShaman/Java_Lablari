
public class StockItem {

	public String stockNo;
	public String name;
	public double price;
	public int extraStock;
	public int totalStock;
	public int num;
	
	public StockItem() {
		// TODO Auto-generated constructor stub
	}
	
	public String getStockNo() {
		return stockNo;
	}



	public void setStockNo(String inp) {
		this.stockNo = inp;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public double getPrice() {
		return price;
	}



	public void setPrice(double price) {
		this.price = price;
	}



	public int getTotalStock() {
		return totalStock;
	}
	
	public void increaseTotalStock(int extra){
		totalStock += extra;
	}



	public void setTotalStock(int totalStock) {
		this.totalStock = totalStock;
	}
	
	public double calculateTotalPrice(){
		double totalprice=0;
		
		return totalprice = price*totalStock;
	}


}
