import java.util.Scanner;

public class Question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner ella = new Scanner(System.in);
		String date, day, mounth, year;
		int y0, y, m, x, d0, d, m0, c;
		System.out.print("Please enter the date as day/month/year: ");
		date = ella.next();
		day = date.substring(0, 2);
		mounth = date.substring(3,5);
		year = date.substring(6);
		  int d1 = Integer.parseInt(day);
	      int m1 = Integer.parseInt(mounth);
	      int y1 = Integer.parseInt(year);
	      y0 = y1 - (14 - m1) / 12;
	      x = y0 + y0/4 - y0/100 + y0/400;
	      m0 = m1 + 12 * ((14 - m1) / 12) - 2;
	      d0 = (d1 + x + 31*m0 / 12) %7;
	      
	      if (d0 == 0)
	    	  	   System.out.println("The date "+date+" is Sunday.");
	    	   else if (d0 == 1)
	    		   System.out.println("The date "+date+" is Monday.");
	    	   else if (d0 == 2)
	    		   System.out.println("The date "+date+" is Tuesday.");
	    	   else if (d0 == 3)
	    		   System.out.println("The date "+date+" is Wednesday.");
	    	   else if (d0 == 4)
	 	    	   System.out.println("The date "+date+" is Thursday.");
	 	       else if (d0 == 5)
	 	    	   System.out.println("The date "+date+" is Friday.");
	 		   else if (d0 == 6)
	 			   System.out.println("The date "+date+" is Saturday.");
	      
	    		  
	    		  
		
		
		
		
	}

}
