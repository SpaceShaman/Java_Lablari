import java.util.Scanner;

public class Question03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=0, b=0 ;
		
		Scanner neon = new Scanner(System.in);
		System.out.println("Please enter the capacity of the first array: ");
		a = neon.nextInt();
		int sayi[] = new int[a+1];
		for (int i = 1; i < sayi.length; i++) 
		{ 
		System.out.print("Please enter the element "+i+" of the first array: ");
		sayi[i] = neon.nextInt();  
		} 
		
		System.out.println("Please enter the capacity of the second array: ");
		b = neon.nextInt();
		int c=0;
		int sayi2[] = new int[b+1];
		for (int j = 1; j < sayi2.length; j++) 
		{ 
		System.out.print("Please enter the element "+j+" of the second array: ");
		sayi2[j] = neon.nextInt();  
		} 
		
		System.out.println("Common elements between two arrays: ");
		for (int j = 1; j < sayi2.length; j++) {
			for( int i=1; i<sayi.length; i++){
				if (sayi[i]==sayi2[j]){
				c=sayi2[j];
				System.out.println(c);
				}}
			}
	}

}
