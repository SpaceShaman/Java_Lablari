import java.util.Scanner;

public class Question1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner dragons = new Scanner(System.in) ;
		String name, surname, year, id, name2, surname21, surname22, sn, year2, id2;
		int n, y;
		System.out.print("Please enter user name:");
		name = dragons.next();
		System.out.print("Please enter user surname:");
		surname = dragons.next();
		System.out.print("Please enter the birth year:");
		year = dragons.next();
		System.out.print("Please enter the ID:");
		id = dragons.next();
		
		name2 = name.toLowerCase();
		surname21 = surname.substring(0,1);
		n = surname.length();
		y = n-1;
		surname22 = surname.substring(y);
		sn = surname21.toUpperCase() + surname22.toUpperCase();
		year2 = year.substring(2);
		id2 = id.substring(0, 3);
		
		
		System.out.print( name +" " +surname+ "'s generated email address is:" +name2 +"." +sn +year2 +id2);
		
		
		
		
		
		
		
	}

}
