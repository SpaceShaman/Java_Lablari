import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		//deneme 1.3
		
		Scanner dream = new Scanner(System.in);
		String name="", name1="", phone="00234567890", phone1="00134567899",
				phone03="648", phone36 ="458", phone68 ="85", phone810="75";
		int age = 126 , age1 = 127;
		System.out.print("Enter your name: ");
		name = dream.nextLine();
			while (name.length() >30 || name.length()<2)
			{
				System.out.print("Incorrect input\r\n" +"Enter your name: ");
				name1 =dream.nextLine();
				name = name1;
				if (name.length() >30 || name.length()<2)
					continue;
				if (name.length() <30 || name.length()>1)
					break;
			}
		System.out.print("Enter your age: ");
		age = dream.nextInt();
			while (age <0 || age>125) 
			{
				System.out.print("Incorrect input\r\n" +"Enter your age: ");
				age1 =  dream.nextInt();
				age = age1;
				break;
			}
		{System.out.print("Enter your phone number: ");
		phone = dream.next();
		if ( phone.length() != 10 || phone.charAt(0) == '0' ) {
		while ( phone.length() != 10 || phone.charAt(0) == '0' )
		 {
			System.out.print("Incorrect input\r\n" +"Enter your phone number: ");
			phone1 = dream.next();
			phone = phone1;	
			if (phone.length() != 10 || phone.charAt(0) == '0' )
				continue;
			if (phone.length() == 10 || phone.charAt(0) != '0' )
				break;
		 }}}
		
		System.out.println("Name: " + name);
		System.out.println("Age: " + age);
		phone03 = phone.substring(0, 3);
		phone36 = phone.substring(3, 6);
		phone68 = phone.substring(6, 8);
		phone810 = phone.substring(8, 10);
		System.out.println("Phone Number: " +phone03 +" " + phone36 +" " + phone68 +" " + phone810);
			
		
		}
		
	
	}


