import java.util.Scanner;

public class Question03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner lost = new Scanner(System.in);
		String input ="";
		System.out.println("Enter a string of 1-25 digits: ");
		input = lost.nextLine();
		
		if(input.length()<=0 || input.length()>25){
			System.out.println("Invalid Input");
			System.exit(0);
		}
		
		for ( int i=0 ; i<input.length(); i++)
			if((input.charAt(i)-48<0) || (input.charAt(i)-48>9)){
				System.out.println("Invalid Input");
				System.exit(0);
			}
		int j, k;
		for (j=0; j<input.length(); j++){
			int counter=0;
			for(k = j+1; k<input.length(); k++){
			if  ((Integer.parseInt(input.substring (j, j+1))<(Integer.parseInt(input.substring (k, k+1)))))
				counter++;
			if(k==input.length()-1)
				System.out.println(input.charAt(j)+":"+counter);}
		}
		System.out.println(input.charAt(input.length()-1)+":0");		
		}
		
	}

