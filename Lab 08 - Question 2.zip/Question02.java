import java.util.Scanner;

public class Question02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner odell = new Scanner(System.in);
		int a= 0,e = 0;
		double max= 0.0;
		
		System.out.print("Please enter the capacity of the array: ");
		a = odell.nextInt();
		int sayi[] = new int[a+1];
		int i=0;
		for (i = 1; i <= a; i++) 
		{ 
		System.out.print("Please enter the element "+i+" of the array: ");
		sayi[i] = odell.nextInt();  
		} 
		for (i = 1; i <= a; i++) 
		{
		  if(!(sayi[i]==sayi[a-(i-1)])){
			  System.out.println("This array is not a Palindrom.");
		  System.exit(0);}
		}
		System.out.println("This array is a Palindrom.");
	}

}
