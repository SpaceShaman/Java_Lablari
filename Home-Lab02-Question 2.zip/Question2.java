import java.util.Scanner;

public class Question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner rem = new Scanner(System.in);

        int num1, num2, num3;

        System.out.print("Enter Integer x: ");
        num1 = rem.nextInt();

        System.out.print("Enter Integer y: ");
        num2 = rem.nextInt();

        System.out.print("Enter Integer z: ");
        num3 = rem.nextInt();
        System.out.println("The order of these numbers is:" ) ;

        if ((num1 > num2 && num1 > num3))
        if(num2 > num3)
        System.out.println(num1 + " -> " + num2 + " -> " + num3);
        else
        System.out.println (+num1 + " -> " + num3 + " -> " + num2);
        
        else if ((num2 > num1 && num2 > num3))
        if(num1 > num3)
        System.out.println(+num2 + " -> " + num1 + " -> " + num3);
        else
        System.out.println(+num2 + " -> " + num3 + " -> " + num1);
        
        else if ((num3 > num1 && num3 > num2))
        if(num1 > num2)
        System.out.println( +num3 + " -> " + num1 + " -> " + num2);
        else
        System.out.println( +num3 + " -> " + num2 + " -> " + num1);
	}
}
