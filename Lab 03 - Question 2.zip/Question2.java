import java.util.Scanner;

public class Question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner giant = new Scanner(System.in) ;
		String match, day, ay, year, s2, winner, city1, city2, loser, s3, s4, ws, ls,s1, city2i,city1i;
		int s2n, nw, s3n, nl,s4n, ch;
		System.out.print("Please enter match string:");
		match = giant.nextLine();
		s2n  = match.indexOf(" ");
		s1 = match.substring(0,s2n);
		year = s1.substring(8, 10 );
		ay = s1.substring(3, 5);
		day = s1.substring(0, 2);
		System.out.println("Date of Match: " +year +"/" +ay +"/" +day) ;
		
		s2 = match.substring(s2n+1);
		nw = s2.indexOf("-");
		winner = s2.substring(0, nw);
		winner = winner.toUpperCase();
		s3n = s2.indexOf(" ");
		s3 = s2.substring(s3n+1);
		city1 = s2.substring(nw+2, s3n);
		city1i = s2.substring(nw+1, nw+2);
		city1i = city1i.toUpperCase();
		city1 = city1i+city1;
		
		nl = s2.indexOf("-");
		loser = s3.substring(0, nl+2);
	    loser = loser.toUpperCase();

		s4n = s3.indexOf(" ");
		s4 = s3.substring(s4n+1);
		ch = s3.indexOf("-");
		city2 = s3.substring(ch+2, s4n);
		city2i = s3.substring(ch+1, ch+2);
		city2i = city2i.toUpperCase();
		city2 = city2i+city2;
				
		
		ws = s4.substring(0, 1);
		ls = s4.substring(2, 3);
		
		System.out.println("Winner: " + winner +" "  + city1);
		System.out.println("Loser: " + loser +" " + city2);
		System.out.println("Score: " +ws +":" +ls);

		
		
		
		
		
		
		

		
		
		
		
		
		
	}

}
