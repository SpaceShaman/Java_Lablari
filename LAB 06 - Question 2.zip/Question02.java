import java.util.Scanner;

public class Question02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner surrender = new Scanner(System.in);
		int i;
		String name, answer, name1;
		
		
		
//		if(answer.equalsIgnoreCase("n")){System.out.println("");}
		
		
//			System.out.println("\n" +"Enter a name and surname: ");
//			name = surrender.nextLine();
			
			do{
				
				System.out.print("Enter a name and surname: ");
			
				name = surrender.nextLine();
				
				i = name.indexOf(" ");
				
				System.out.println((name.substring(0, 1)).toUpperCase() +
						(name.substring(1,i)).toLowerCase() +" " + (name.substring(i+1, i+2)).toUpperCase() + 
						(name.substring(i+2)).toLowerCase());
				
//			char one;
//			String two, four;
//			char three;
//			i = name.indexOf(" ");
//			
//			one =name.charAt(0); 
//			String one1 = (String.valueOf(one).toUpperCase());
//			two = name.substring(1,i);
//			two = two.toLowerCase() ;
//			three = name.charAt(i+1);
//			String three1 = (String.valueOf(one).toUpperCase());
//			four = name.substring(i+2);
//			four = four.toLowerCase()  ;
//			
//			 String sentence =one1 +two +" " +three1  +four;
//					 System.out.println(sentence);

//				System.out.println("\n" +"Again? (y/n): ");
//				answer = surrender.next();
			
			System.out.println("\n" +"Again? (y/n): ");
			answer = surrender.next();
//			if (answer.equalsIgnoreCase("y"))
//				continue;
//			System.out.println("\n" +"Enter a name and surname: ");
//			surrender.nextLine();
//			name = surrender.nextLine();
			
//			
//			if (answer.equalsIgnoreCase("n"))
//				break;
//			
		}while (answer.equalsIgnoreCase("y") );
			
		}
		
	}


