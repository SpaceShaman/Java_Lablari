
public class Myfirstprogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Hello world!");
	}

}
