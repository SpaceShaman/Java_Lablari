import java.util.Scanner;

public class Lab04Q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner ajr = new Scanner(System.in);
		String num1;
		int num =11;
	
		System.out.print("Enter input number: ");
			num1 = ajr.nextLine();
		
		if (num1.equalsIgnoreCase("One")){
			num = 1;
		}
		else if (num1.equalsIgnoreCase("Two")){
			num = 2;
		}
		else if (num1.equalsIgnoreCase("Three")){
			num = 3;
		}
		else if (num1.equalsIgnoreCase("Four")){
			num = 4;
		}
		else if (num1.equalsIgnoreCase("Five")){
			num = 5;
		}
		else if (num1.equalsIgnoreCase("Six")){
			num = 6;
		}
		else if (num1.equalsIgnoreCase("Seven")){
			num = 7;
		}
		else if (num1.equalsIgnoreCase("Eight")){
			num = 8;
		}
		else if (num1.equalsIgnoreCase("Nine")){
			num = 9;
		}if(num>9 || num <=0){
			System.out.println("Input number must be between 1-9!");
		}else{
			if (num%2==0){
			System.out.println(num +" is even.");
		}
			else if (num%2 == 1){
			System.out.println(num +" is odd.");
		}
		}
			
		

}}
