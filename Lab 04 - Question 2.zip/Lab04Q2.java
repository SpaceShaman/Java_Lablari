import java.util.Scanner;

public class Lab04Q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner riots = new Scanner(System.in);
		String namesalary, year, name, salary;
		int nameend, yearofemp, year1, salary1;
		double bonus1, bonus;
		
		System.out.print("Enter employee name and salary: ");
		namesalary = riots.nextLine();
		System.out.print("Enter first year of employment: ");
		year = riots.next();
		
		
		nameend = namesalary.indexOf(" ");
		name = namesalary.substring(0, nameend);
		salary = namesalary.substring(nameend+1);
		salary1 = Integer.parseInt(salary);
		
		year1 = Integer.parseInt(year);
		yearofemp = (2018 - year1);
		bonus1 = Math.round (yearofemp * 100) / 100.0;
		bonus = (salary1 / 100.0)*5.0;
		
		if (yearofemp>5){
			System.out.print("Net bonus for "+name +" is " +bonus +".");
		}
		else {
			System.out.print("NO bonus for "+name +".");
		}
		
		
		
	}

}
