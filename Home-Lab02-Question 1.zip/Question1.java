import java.util.Scanner;


public class Question1 {

    public static void main(String[] args) {

        Scanner sinatra = new Scanner(System.in);

        int num1, num2, num3, max;

        System.out.print("Enter Integer x: ");
        num1 = sinatra.nextInt();

        System.out.print("Enter Integer y: ");
        num2 = sinatra.nextInt();

        System.out.print("Enter Integer z: ");
        num3 = sinatra.nextInt();

        max = num1;
		if (num2 >= max)
		max = num2;
		
		if (num3 >= max)
		max = num3;
       
        System.out.println("The maximum of these numbers is: " +max);
    }
}